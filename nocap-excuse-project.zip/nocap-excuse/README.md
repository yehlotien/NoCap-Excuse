# NoCap Excuse 😭

> Drop your situation. Get your alibi. No cap.

An AI-powered excuse generator built with React + Vite (frontend) and Node.js + Express (backend), powered by OpenAI GPT-4o.

---

## Project Structure

```
nocap-excuse/
├── backend/
│   ├── server.js        # Express API server
│   ├── package.json
│   └── .env.example     # Copy to .env and add your key
└── frontend/
    ├── src/
    │   ├── App.jsx      # Main React component
    │   ├── main.jsx     # React entry point
    │   └── index.css    # Tailwind + custom styles
    ├── index.html
    ├── vite.config.js   # Proxies API calls to backend
    ├── tailwind.config.js
    └── package.json
```

---

## Setup & Run

### 1. Get an OpenAI API Key
Go to https://platform.openai.com/api-keys and create a key.

### 2. Set up the Backend

```bash
cd backend
cp .env.example .env
# Edit .env and paste your OpenAI API key
npm install
npm run dev   # Starts on http://localhost:3001
```

### 3. Set up the Frontend

```bash
cd frontend
npm install
npm run dev   # Starts on http://localhost:5173
```

### 4. Open the App
Visit http://localhost:5173 in your browser.

---

## API Endpoints

| Method | Route | Body | Response |
|--------|-------|------|----------|
| POST | `/generate-excuses` | `{ situation: string }` | `{ excuses: string[] }` |
| POST | `/generate-story` | `{ selectedExcuse: string }` | `{ story: string }` |

---

## How It Works

1. User describes their situation in the text box
2. Frontend calls `POST /generate-excuses` → backend asks GPT-4o for 5 excuses
3. User clicks one excuse card
4. Frontend calls `POST /generate-story` → backend asks GPT-4o to expand it into a story
5. User can copy the story, try another excuse, or start over

---

## Tech Stack

- **Frontend**: React 18, Vite, Tailwind CSS
- **Backend**: Node.js, Express
- **AI**: OpenAI GPT-4o (chat completions)
- **Fonts**: Syne (display) + DM Sans (body)
